import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  constructor(private loginService:UserService ) { }

  ngOnInit() {
    this.loginService.login({
      "password": "qwerty123",
      "email": "test@gmail.com"
  }).subscribe((res)=>{
      console.log(res)
      this.loginService.encryptData(res)
    })
  }

}
